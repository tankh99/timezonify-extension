# timezonify-extension
Makes all timings local. 

v2.0: Simply highlight the text you want to convert, click on Timezonify and voila! It overlays the new timing over the highlighted text. Double-click the overlay if you wish to delete it

v1.0: Simply select the timing you want to convert, right-click to open up the context menu and then Timezonify!
